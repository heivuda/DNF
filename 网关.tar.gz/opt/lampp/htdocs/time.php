<?php

// 获取中国时间，即上海时区时间
function getChinaTime($format = "Y-m-d H:i:s") {
  $chinaTime = date($format, strtotime('now'));
  return $chinaTime;
}

echo getChinaTime('Y-m-d H:i:s');

?>
